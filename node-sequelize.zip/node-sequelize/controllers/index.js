const classroom = require('./classroom');

module.exports = {
  classroom,
};

const classroom = require('./classroom');
const student = require('./student');

module.exports = {
  classroom,
  student,
};

const classroom = require('./classroom');
const student = require('./student');
const lecturer = require('./lecturer');

module.exports = {
  classroom,
  student,
  lecturer,
};

const classroom = require('./classroom');
const student = require('./student');
const lecturer = require('./lecturer');
const course = require('./course');

module.exports = {
  classroom,
  student,
  lecturer,
  course,
};
